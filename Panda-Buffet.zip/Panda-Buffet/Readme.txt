Team Panda Buffet

Members
 Tristan Morris	
 Kristopher Crooks
 Randy McGarity	

Pages:
	Index/Home
	About
	Contact
	Menu
	Careers
	Reviews

Status:
	Incomplete (~74% complete)

Compatability:
	Desktop:
		Chrome 	- Compatable
		Firefox - Compatable
		IE	- Not Tested
		Safari	- Not Tested
	Mobile:
		Chrome	- Compatable
		Firefox	- Not Tested
		Safari	- Not Tested

Known Issues and notes:
	The index page's paragraph 2 clips into the header directly below it at smaller screen sizes
	Customer Review Page is incomplete
	Contact Us page could use more information
	Index page could use more pictures
	